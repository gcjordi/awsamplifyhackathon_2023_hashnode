// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

/// <reference types="react-scripts" />

// See https://github.com/facebook/create-react-app/issues/6560 for why this file exists.
